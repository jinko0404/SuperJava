package org.Super.day09.member.model;

public class Member {
	//memberID
	//memberPw
	//memberName
	//memberEmail
	//memberPhone
}
